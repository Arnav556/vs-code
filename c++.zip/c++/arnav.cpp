
// #include<iostream> //preprocessor directive
// #include<string>
// using namespace std;
// // class rectangle{
// //     private:
// //     int length;
// //     int breath;
// //     public:
// //     void setlength(int l){
// //         length=l;
// //         if (l>0){
// //             length=1;       
// //         }else{
// //             length=0;
// //         }
// //     }
// //     void setbreath(int b){
// //         breath=b;
// //         if(b>0){
// //             breath= 1;    
// //         }else{
// //             breath=0;
// //         }
// //     }
// //     int getlength(){
// //         return length;
// //     }
// //     int getbreath(){
// //         return breath;
// //     }
// //     int area(){
// //         return length*breath;
// //     }
// //     int perimeter(){
// //         return  2*(length+breath);
// //     }
// // };
// //     int main(){
// //         // rectangle r1,r2;
// //         // r1.length = 10;
// //         // r1.breath = 5;
// //         // cout<<"area is"<<r1.area()<<endl;
// //         // cout<<"perimeter is"<<r1.perimeter()<<endl;
// //         // r2.length = 7;
// //         // r2.breath = 5;
// //         // cout<<r2.area()<<endl;
// //         // cout<<r2.perimeter()<<endl;
// //         //POINTER TO OBJECT
// //         // rectangle *ptr = new rectangle; //dynamic object created in a heap earlier i created an object
// //         // ptr->length=10;
// //         // ptr->breath=5;
// //         // cout<<ptr->area()<<endl;
// //         // cout<<ptr->perimeter()<<endl;
// //         //DATA HIDING
// //         rectangle r1;
// //         r1.setlength(10);
// //         r1.setbreath(0);
// //         cout<<r1.getlength()<<endl;
// //         cout<<r1.getbreath()<<endl;
// //         cout<<r1.area()<<endl;
// //         cout<<r1.perimeter()<<endl;

// //     return 0;
// //     }

// class student{
//     private:
//     int rollno;
//     string name;
//     int sub1,sub2,sub3;
//     int total;
//     char grade;

//     public:
//     //used for input
//     void getdata(){
//         cout<<"enter the rollno";
//         cin>>rollno;

//         cout<<"enter the name";
//         cin>>name;

//         cout<<"enter marks of 3 subjects";
//         cin>> sub1 >> sub2 >> sub3;
//     }
//     //method to calculate total marks
//     void calculatetotal(){
//         total = sub1+sub2+sub3;
//     }
//     void calculategrade(){
//         float avg = total/3.0;
//         if(avg>90){
//            grade ='A';
//         }
//         else if(avg>75){
//             grade = 'B';
//         }
//         else if(avg<75){
//             grade = 'c';
//         }
//     }
//     void displaydata(){
//     cout << "\nStudent Details" << endl;
//     cout << "Roll Number: " << rollno << endl;
//     cout << "Name: " << name << endl;
//     cout << "Marks: " << sub1 << " " << sub2 << " " << sub3 << endl;
//     cout << "Total Marks: " << total << endl;
//     cout << "Grade: " << grade << endl;
//     }
// };
// int main(){
//     student s;
//     s.getdata();
//     s.calculatetotal();
//     s.calculategrade();
//     s.displaydata();
//     return 0;
// }

// #include<iostream>
// #include<string>
// using namespace std;
// class Car{
//     private:
//     string carname;
//     int speed;
//     public:
//     void getdata(){
//         cout<< "enter carname";
//         cin>>carname;
//         cout<< "enter speed";
//         cin>>speed;
//     }
//     void displaydata(){
//         cout<<"brand name"<<carname<<endl;
//         cout<<"speed"<< speed<<endl;
//     }
//     void blowhorn(){
//         cout<<"horn beep beep"<<endl;
//     }


// };
// int main(){
//     Car c;
//     c.getdata();
   
//     c.displaydata();
//     c.blowhorn();
//     return 0;

// }


// #include<iostream>
// using namespace std;
// class bankaccount{
//     private:
//     int accountnumber;
//     string name;
//     float balance;
//     public:
//     void getdata(){
//         cout<<"enter your account number:"<<endl;
//         cin>>accountnumber;
//         cout<<"enter name:"<<endl;
//         cin>>name;
//         cout<<"enter initial balance:"<<endl;
//         cin>>balance;
//     }
//     void deposit(){
//         float amount;
//         cout<< "enter amound to deposit:"<<endl;
//         cin>>amount;
//         if(amount>0){
//             balance= balance+amount;
//             cout<<"deposit successful"<<endl;
//         }
//         else{
//             cout<<"invalid ammount";
//         }

//     }
//     void withdraw(){
//         float amount;
//         cout<<"enter amount to withdraw"<<endl;
//         cin>>amount;
//         if(amount>0 && amount<=balance){
//             balance= balance-amount;
//             cout<<"withdraw successful"<<endl;
//         }
//         else{
//             cout<<"invalid balance"<<endl;
//         }

//     }
//     void displaybalance(){ //display fun use for details
//         cout<<"account details"<<endl;
//         cout<<"account no:"<<accountnumber<<endl;
//         cout<<"customer name"<<name<<endl;
//         cout<<"balance"<<balance<<endl;
//     }
// };
//     int main(){
//         bankaccount b;
//         b.getdata();
//         b.deposit();
//         b.withdraw();
//         b.displaybalance();
//         return 0;

//     }
    


#include<iostream>
#include<string>
using namespace std;
class Student{
    int rollno;
    string name;
    public:
    Student(){
        int rollno = 8;
        string name = "arnav";
    }
    void displaydata(){
        cout<<"roll no:"<<rollno<<endl;
        cout<<"name"<<name<<endl;


    }
};
    int main(){
        Student s; 
        s.displaydata();
    return 0;
    }

    



























