
// #include<iostream> //preprocessor directive
// using namespace std;
// class rectangle{
//     public:
//     int length;
//     int breath;
//     int area(){
//         return length*breath;
//     }
//     int perimeter(){
//         return  2*(length+breath);
//     }
// };
//     int main(){
//        rectangle r1,r2;
//        r1.length = 10;
//        r1.breath = 5;
//        cout<<"area is"<<r1.area()<<endl;
//        cout<<"perimeter is"<<r1.perimeter()<<endl;
//        r2.length = 5;
//        r2.breath = 2;
//        cout<<r2.area()<<endl;
//        cout<<r2.perimeter()<<endl;
    //rectangle *ptr;

    //return 0;
   //}


//STUDY AND IMPLEMENT DATA REPERESTATION 


//implement a prgoram that user std, sort fun to arrange a list of integer and std find if fun to locate the first odd number in that list
//iterators falls if no such 
//parameter first , last is a range which contains all the element btw first and last 
//ped is a uninary fun that accepts that element in the range as an arguement and returns a value in boolean 
//eg:_
// #include <iostream>
// #include <algorithm>
// #include <array>

// using namespace std;
// bool isodd(int i){
//     return i%2;
// }

// int main(){
//     array<int,6> arr ={5,4,6,3,6,8};
//     sort(arr.begin(),arr.end());
//     cout<<"sorted list:";
//     for(auto i :arr){
//         cout<<i<<" ";

//     }
//     array<int,6>::iterator it;
//     it=find_if(arr.begin(),arr.end(),isodd);
//     if (it != arr.end()){
//         cout<<"first odd number : "<< *it;
//     }
    
//     return 0;
    
    
// }






// array iterator 
//array<int> :: iterator it;
//it= find_if(arr.begin(), arr.end());
//isodd;




//FOR FIRST EVEN NUMBERS
// #include <iostream>
// #include <algorithm>
// #include <array>

// using namespace std;
// bool iseven(int i){
//     return i%2==0;
// }

// int main(){
//     array<int,6> arr ={5,4,6,3,6,8};
//     sort(arr.begin(),arr.end());
//     cout<<"sorted list:";
//     for(auto i :arr){
//         cout<<i<<" ";

//     }
//     array<int,6>::iterator it;
//     it=find_if(arr.begin(),arr.end(),iseven);
//     if (it != arr.end()){
//         cout<<"first even number : "<< *it;
//     }
    
//     return 0;
    
    
// }
// question nahi pata
// #include <iostream>
// #include <algorithm>
// #include <vector>

// using namespace std;
// int addone(int a){
//     return a+1;
// }
// // int main(){
// //     vector<int>v1={1,5,6,8};
// //     vector<int>v2(v1.size());
// //     transform(v1.begin(),v1.end(),v2.begin(),addone);
// //     for(auto i:v2){
// //     cout<<i<<" ";
    
// //     }
// //     return 0; 
        
// // }
// //lowercase string into uppercase transfer fun is used to appply the given operation to a range of    and store the result in another range it has maily three argument
// #include <iostream>
// #include <algorithm>
// #include <cctype>
// #include <string>
// using namespace std;

// int main() {
//     string str = "hello";
//     string result(str.size(), ' ');
//     transform(str.begin(), str.end(), result.begin(), ::toupper);
//     cout << result;

//     return 0;
// }
// #include <iostream>
// #include <cctype>
// using namespace std;

// int main() {
//     string str = "hello";

//     for (char &ch : str) {
//         ch = toupper(ch);
//     }

//     cout << str;

//     return 0;
//} 
// 18/08/2026 
//1. write a menu driven c++ program to implement a deque  the program should support insert at front aur rear , deletion from front or rear, display,searching , and cheching whether the dq is empty
//2.implement a simple undo or redo using a deque where operations can be added and remove from either end
//3. write a cpp program using deque (string) to simulate browser history . provide operations to visit a page go back and display the current history

// #include <iostream>
// #include <deque>
// using namespace std;

// int main() {
//     deque<int> dq;
//     int choice, x;

//     do {
//         cout << "\n1. Insert Front";
//         cout << "\n2. Insert Rear";
//         cout << "\n3. Delete Front";
//         cout << "\n4. Delete Rear";
//         cout << "\n5. Display";
//         cout << "\n6. Search";
//         cout << "\n7. Check Empty";
//         cout << "\n8. Exit";
//         cout << "\nEnter choice: ";
//         cin >> choice;

//         switch(choice) {

//         case 1:
//             cin >> x;
//             dq.push_front(x);
//             break;

//         case 2:
//             cin >> x;
//             dq.push_back(x);
//             break;

//         case 3:
//             if(dq.empty())
//                 cout << "Deque is empty";
//             else
//                 dq.pop_front();
//             break;

//         case 4:
//             if(dq.empty())
//                 cout << "Deque is empty";
//             else
//                 dq.pop_back();
//             break;

//         case 5:
//             for(int x : dq)
//                 cout << x << " ";
//             break;

//         case 6:
//             cin >> x;
//             {
//                 bool found = false;

//                 for(int a : dq) {
//                     if(a == x)
//                         found = true;
//                 }

//                 if(found)
//                     cout << "Found";
//                 else
//                     cout << "Not Found";
//             }
//             break;

//         case 7:
//             if(dq.empty())
//                 cout << "Deque is empty";
//             else
//                 cout << "Deque is not empty";
//             break;
//         }

//     } while(choice != 8);

//     return 0;
// }


// #include <iostream>
// #include <deque>
// using namespace std;

// int main() {
//     deque<string> undo, redo;
//     int choice;
//     string op;

//     do {
//         cout << "\n1. Add Operation";
//         cout << "\n2. Undo";
//         cout << "\n3. Redo";
//         cout << "\n4. Display";
//         cout << "\n5. Exit";
//         cout << "\nEnter choice: ";
//         cin >> choice;

//         switch(choice) {

//         case 1:
//             cin >> op;
//             undo.push_back(op);
//             break;

//         case 2:
//             if(undo.empty())
//                 cout << "Nothing to undo";
//             else {
//                 op = undo.back();
//                 undo.pop_back();
//                 redo.push_back(op);
//             }
//             break;

//         case 3:
//             if(redo.empty())
//                 cout << "Nothing to redo";
//             else {
//                 op = redo.back();
//                 redo.pop_back();
//                 undo.push_back(op);
//             }
//             break;

//         case 4:
//             cout << "Undo: ";
//             for(string x : undo)
//                 cout << x << " ";

//             cout << "\nRedo: ";
//             for(string x : redo)
//                 cout << x << " ";
//             break;
//         }

//     } while(choice != 5);

//     return 0;
// }


//DEQUE
// WAP TO C++ DEQUE (string)  to simulate browser history to proved operation to visit a page go back and display current history
// #include <iostream>
// #include <deque>
// using namespace std;

// int main() {
//     deque<string> history;
//     string page;
//     int choice;

//     do {
//         cout << "\n--- Browser History ---\n";
//         cout << "1. Visit Page\n";
//         cout << "2. Go Back\n";
//         cout << "3. Display History\n";
//         cout << "4. Exit\n";
//         cout << "Enter your choice: ";
//         cin >> choice;

//         switch(choice) {

//             case 1:
//                 cout << "Enter page: ";
//                 cin >> page;
//                 history.push_back(page);
//                 cout << "Page visited.\n";
//                 break;

//             case 2:
//                 if(history.size() > 1) {
//                     history.pop_back();
//                     cout << "Went back to: " << history.back() << endl;
//                 }
//                 else {
//                     cout << "No previous page available.\n";
//                 }
//                 break;

//             case 3:
//                 if(history.empty()) {
//                     cout << "History is empty.\n";
//                 }
//                 else {
//                     cout << "Browser History:\n";

//                     for(string p : history) {
//                         cout << p << endl;
//                     }

//                     cout << "Current Page: "
//                          << history.back() << endl;
//                 }
//                 break;

//             case 4:
//                 cout << "Exiting...\n";
//                 break;

//             default:
//                 cout << "Invalid choice!\n";
//         }

//     } while(choice != 4);

//     return 0;
// }


// parking lot management  using stack 1. park a car 2. remove a car 3. display packed cars 4. search for a car
// #include <iostream>
// #include <stack>
// using namespace std;

// int main() {
//     stack<string> parking;
//     int choice;
//     string car;

//     do {
//         cout << "\n--- PARKING LOT MANAGEMENT ---\n";
//         cout << "1. Park a car\n";
//         cout << "2. Remove a car\n";
//         cout << "3. Display parked cars\n";
//         cout << "4. Search for a car\n";
//         cout << "5. Exit\n";
//         cout << "Enter your choice: ";
//         cin >> choice;

//         switch(choice) {

//             case 1:
//                 cout << "Enter car number: ";
//                 cin >> car;
//                 parking.push(car);
//                 cout << "Car parked successfully.\n";
//                 break;

//             case 2:
//                 if(parking.empty()) {
//                     cout << "Parking lot is empty.\n";
//                 }
//                 else {
//                     cout << "Removed car: " << parking.top() << endl;
//                     parking.pop();
//                 }
//                 break;

//             case 3:
//                 if(parking.empty()) {
//                     cout << "Parking lot is empty.\n";
//                 }
//                 else {
//                     stack<string> temp = parking;

//                     cout << "Parked cars:\n";
//                     while(!temp.empty()) {
//                         cout << temp.top() << endl;
//                         temp.pop();
//                     }
//                 }
//                 break;

//             case 4:
//                 cout << "Enter car number to search: ";
//                 cin >> car;

//                 {
//                     stack<string> temp = parking;
//                     bool found = false;

//                     while(!temp.empty()) {
//                         if(temp.top() == car) {
//                             found = true;
//                             break;
//                         }
//                         temp.pop();
//                     }

//                     if(found)
//                         cout << "Car found in parking lot.\n";
//                     else
//                         cout << "Car not found.\n";
//                 }
//                 break;

//             case 5:
//                 cout << "Program ended.\n";
//                 break;

//             default:
//                 cout << "Invalid choice.\n";
//         }

//     } while(choice != 5);
    

//     return 0;
// }

// use auto for variable  type deduction and implement designated intializer to initialize a struct representing a user profile



// #include <iostream>
// using namespace std;

// struct UserProfile {
//     string name;
//     int age;
//     string city;
// };

// int main() {
//     auto user = UserProfile{
//         .name = "Arnav",
//         .age = 19,
//         .city = "Greater Noida"
//     };

//     cout << "Name: " << user.name << endl;
//     cout << "Age: " << user.age << endl;
//     cout << "City: " << user.city << endl;

//     return 0;
// }

// write a constexp function to calculate the factorial of a number at compile time and use it to initialize a constexpr variable
// it allows to be evaluated at compile time when it's arguements are compile time constants and the given expression is valid?? 


// factorial n! =  n*(n-1) * (n-2) * ... * 1   
// = n*(n-1)!  for n>0

// constexpr int factorial(int n) {
//     return (n <= 1) ? 1 : n * factorial(n - 1);
// }

// constexpr int result = factorial(5);


//demonstrate memory management using unique_ptr automatically manage lifetime of dynamically allocated object and ensure that the object is deleted when the unique pointer goes out of scope
//unique pointer is a smart pointer that exclusively owns a dynamically allocated object and automatically deallocates the memory when it goes out of scope. It is defined in the <memory> header and is part of the C++11 standard and later versions.

//may_unique<classname//datatype>() //create a unique pointer to an object of type classname
//when pointer goes out of scope, the destructor of unique_ptr is called, which automatically deletes the object it owns. This helps prevent memory leaks and ensures proper resource management in C++ programs.

//unique_ptr<A> ptr = make_unique<A>(args); //create a unique pointer to an object of type A and initialize it with the given arguments
//ptr->member_function(); //access member function of the object owned by the unique pointer

//ptr-> display();
// #include <iostream>
// #include <memory>
// using namespace std;

// class A {
// public:
//     void display() {
//         cout << "Object is being used" << endl;
//     }
//     ~A() {
//         cout << "Object deleted automatically" << endl;
//     }
// };

// int main() {
//     unique_ptr<A> ptr = make_unique<A>();
//     ptr->display();
//     return 0;
// }

//  three way comparison :-> spaceship operator (<=>)
// write a program to compare two interger value by using the spaceship operator and display the result of the comparison



// #include <iostream>
// #include <compare>
// using namespace std;

// int main() {
//     int a = 10, b = 20;

//     auto result = a <=> b;

//     if (result < 0)
//         cout << "First value is smaller";
//     else if (result == 0)
//         cout << "Both values are equal";
//     else
//         cout << "First value is greater";

//     return 0;
// }


// implement the date class and use spaceship operator to automatically generate or comparison  operators for the class. The date class should have member variables for day, month, and year, and should implement the spaceship operator to compare two date objects based on their chronological order.



// #include <iostream>
// using namespace std;

// class Date {
// public:
//     int day, month, year;

//     Date(int d, int m, int y) : day(d), month(m), year(y) {}

//     bool operator<(const Date& other) const {
//         if (year != other.year) return year < other.year;
//         if (month != other.month) return month < other.month;
//         return day < other.day;
//     }

//     bool operator>(const Date& other) const {
//         return other < *this;
//     }

//     bool operator==(const Date& other) const {
//         return day == other.day && month == other.month && year == other.year;
//     }
// };

// int main() {
//     Date date1(15, 8, 2025);
//     Date date2(20, 8, 2025);

//     if (date1 < date2)
//         cout << "Date1 is earlier";
//     else if (date1 > date2)
//         cout << "Date1 is later";
//     else
//         cout << "Both dates are equal";

//     return 0;
//}

// utility library structure binding :- use structure binding to unpack the values of a struct representing a point in 2D space and print the coordinates

// #include <iostream>
// #include <tuple>
// using namespace std;
 



#include <iostream>
#include <string>
#include <utility>
using namespace std;

pair<string, int> getstudent()
{
    return make_pair("Arnav", 19);
}

int main()
{
    pair<string, int> student = getstudent();

    string name = student.first;
    int age = student.second;

    cout << name << " " << age << endl;

    return 0;
}

// #include <iostream>
// using namespace std;

// int main()
// {
//     cout << "Hello Arnav!";
//     return 0;
// }




// perfect forwarding :- preserve the value of an argument when passing it through an generic funcction to another function , it uses the forwarding reference usually T&& in a function template together with std::forward<T>() it was first introduced in c++11,
//syntax template<typename T>
//VOID WRAPPER(t&& avg)
// {process(std::forward<T>avg)};
//forward l values and r values 
//forwarding lvalues and rvalues
/*
#include<iostream>
#include<utility>
using namespace std;
void process(int &x){
cout<<'Lvalye'<<x<<endl;
}
void process(int &&x){
process(x);
}










int main(){
int x=10;

wrapper(x);
wrapper(20);
return 0;
}
Note:- it doesn't make a variable constant teh variable can be modified later it gurantee static initiliation only
it's value  changed in presist in different function call and different scope
contraint c=0;

std::move :-
suppose we are developing a bamking application and we have a class representing a bank account. The class has a member function that transfers funds from one account to another. When we transfer funds, we want to move the ownership of the funds from the source account to the destination account, rather than copying them. This is where std::move comes in handy. calculated during camprison . while the number of active account can change during runtime


UTILITY LIBRARY :- utility library provides a collection of utility functions and classes that are commonly used in C++ programming. It includes features such as pair, tuple, move semantics, and more. The utility library is part of the C++ Standard Library and is included in the <utility> header file.
std::optional :- std::optional is a feature introduced in C++17 that provides a way to represent optional values. It allows you to indicate that a value may or may not be present, providing a safer alternative to using pointers or sentinel values. std::optional is defined in the <optional> header and is part of the C++ Standard Library.
it is useful when a functin may not always return a valid value, or when a variable may not always have a meaningful value. It helps to avoid null pointer dereferences and provides a clear way to handle cases where a value is absent.

example:- in a student management system a student maye or may not have a scholarship amount
syntax:- std::optional<int> scholarshipAmount;
typesafe union that can store one of several types of values, but only one at a time. It is useful when you want to represent a value that can be of different types, but you want to ensure that only one type is active at any given time. std::variant is defined in the <variant> header and is part of the C++ Standard Library.





*/
