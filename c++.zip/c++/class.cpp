#include<iostream>
using namespace std;
// class rectangle{
//     private:
//     double length;
//     double breadth;
//     double area;
//     double perimeter;

//     public:
//     rectangle(double l,double b){
//         length=l;
//         breadth=b;
//     }
//     void setarea(){
//         area = length*breadth;
//     }
//     void setperimeter(){
//     perimeter = 2*(length+breadth);
//     }
//     void issquare(){
//         if (length==breadth){
//             cout<<"it is square"<<endl;
//         }else{
//             cout<<"it is rectangle"<<endl;
//         }
//     }
//     void display(){
//         cout<< "area of rectangle:  "<<area <<endl;
//         cout<< "perimeter of rectangle:  "<< perimeter<<endl;
//     }


// };
// int main(){
//     rectangle r(6.0,6.0);
//     r.setarea();
//     r.setperimeter();
//     r.issquare();
//     r.display();

// return 0;
// }
// class weatherstation{
//     private:
//     float humidity;
//     float temperature;
//     float pressure;
//     public:
//     void weather(float h, float t, float p){
//         humidity= h;
//         temperature=t;
//         pressure = p;
//     }
//     void display(){
//         cout<< humidity <<endl;
//         cout<< temperature<< endl;
//         cout<< pressure<< endl;

//     }

// };
// int main(){
//     weatherstation w;
//     w.weather(2.4,2.5,4.5);
//     w.display();
//     return 0;
// }

// class electricmotor{
//     public:
//     int battery =45;

// };
// class gasengine{
//     public:
//     int gas=45;


// };

// class hybridvechicle:public electricmotor,public gasengine{
//     public:
//     void display()
// {
//     cout<< gas<<endl;
//     cout<< battery << endl;
// }
// };
// int main(){
//     hybridvechicle h;
//     h.display();
//     return 0;
// }


// class shape{
//     public:
//     void virtual draw(){
//         cout<<"drawing shape"<<endl;
//     }
    
// };
// class circle:public shape{
//     public:
//     void draw(){
//         cout<<"drawing cicle "<<endl;
//     }
// };
// class re



// class student{
//     private:
//     int marks;
//     double attendance;
//     string name;
//     int rollno;
//     public:
//     student(int m, double a, string n, int roll){
//         marks=m;
//         attendance= a;
//         name = n;
//         rollno= roll;
//     }
//     void updatemarks(int m){
//         marks = m;

//     }
//     void viewreport(){
//         cout<<"marks"<<marks<<endl;
//         cout<< attendance<<endl;
//         cout<< name<<endl;
//         cout<< rollno<<endl;

//     }


    


// };
// int main(){
//     student s(101,56.4,"arnav", 56);
//     s.viewreport();
//     s.updatemarks(574);
//     cout<<"afterupadate"<<endl;
//     s.viewreport();
//     return 0;


// }

// class pateint{
//     private:
//     int pateintid;
//     float  bill;
//     string name;
//     public:
//     pateint(int ptid, float b, string n){
//         pateintid = ptid;
//         bill = b;
//         name = n;
//     }
//     void updatebill( float b){
//         bill = b;
//     }
//     void display(){
//         cout<< pateintid<<endl;
//         cout<< bill<<endl;
//         cout<< name<<endl;

//     }


// };
// int main(){
//     pateint p(1 , 1000, "ARNAV");
//     p.display();

//     p.updatebill(89);
//     p.display();

//     return 0;
// }



class test{
    private: 
    int = 10;
    public:
    test(){
        x=10;

    }
    virtual void show(test){

};
void show(test t){
    
}








